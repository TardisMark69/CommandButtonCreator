#include "mainwindow.h"
#include "editdialog.h"

#include <QAction>
#include <QCoreApplication>
#include <QEvent>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMenu>
#include <QMenuBar>
#include <QMessageBox>
#include <QMouseEvent>
#include <QProcess>
#include <QPushButton>
#include <QResizeEvent>
#include <QScrollArea>
#include <QToolBar>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , scrollArea(nullptr)
    , canvas(nullptr)
{
    setupUI();

    const QString exeDir = QCoreApplication::applicationDirPath();
    loadFromJson(exeDir + "/buttons.json");
}

MainWindow::~MainWindow()
{
    const QString exeDir = QCoreApplication::applicationDirPath();
    saveToJson(exeDir + "/buttons.json");
}

void MainWindow::setupUI()
{
    setWindowTitle("Command Button Creator");
    resize(1000, 700);

    QMenuBar *appMenuBar = new QMenuBar(this);
    setMenuBar(appMenuBar);

    QMenu *helpMenu = appMenuBar->addMenu("Help");
    QAction *aboutAction = helpMenu->addAction("About");
    connect(aboutAction, &QAction::triggered, this, [this]() {
        QMessageBox::about(this,
                           "About",
                           "Command Button Creator\n\n"
                           "Created by Mark Mcdougal\n"
                           "March 5, 2026");
    });

    QToolBar *toolbar = addToolBar("Main Toolbar");
    toolbar->setMovable(false);

    QPushButton *addButton = new QPushButton("Add Button", this);
    QPushButton *organizeButton = new QPushButton("Organize", this);
    QPushButton *sameSizeButton = new QPushButton("Make All Same Size", this);

    sameSizeButton->setToolTip(
        "Resize every command button to match the most recently selected button");

    toolbar->addWidget(addButton);
    toolbar->addWidget(organizeButton);
    toolbar->addWidget(sameSizeButton);

    connect(addButton, &QPushButton::clicked, this, &MainWindow::addNewButton);
    connect(organizeButton,
            &QPushButton::clicked,
            this,
            &MainWindow::organizeButtons);
    connect(sameSizeButton,
            &QPushButton::clicked,
            this,
            &MainWindow::makeAllButtonsSameSize);

    scrollArea = new QScrollArea(this);
    scrollArea->setWidgetResizable(false);
    scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);

    canvas = new QWidget();
    canvas->setStyleSheet("background-color: #20B2AA;");
    canvas->setMinimumSize(800, 600);
    canvas->resize(800, 600);
    canvas->installEventFilter(this);

    scrollArea->setWidget(canvas);
    setCentralWidget(scrollArea);
}

bool MainWindow::eventFilter(QObject *watched, QEvent *event)
{
    if (watched == canvas && event->type() == QEvent::MouseButtonPress) {
        const auto *mouseEvent = static_cast<QMouseEvent *>(event);
        if (mouseEvent->button() == Qt::LeftButton) {
            clearSelection();
        }
    }

    return QMainWindow::eventFilter(watched, event);
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
    QMainWindow::resizeEvent(event);
    updateCanvasExtent();
}

void MainWindow::addNewButton()
{
    createButton("New Button", "", QPoint(50, 50), QSize(120, 40));
}

void MainWindow::createButton(const QString &label,
                              const QString &command,
                              const QPoint &pos,
                              const QSize &size)
{
    CommandButton *button = new CommandButton(canvas);
    button->setButtonLabel(label);
    button->setCommandText(command);
    button->move(pos);
    button->resize(size);
    button->show();

    connect(button, &CommandButton::rightClicked, this, &MainWindow::editButton);
    connect(button,
            &CommandButton::executeCommand,
            this,
            &MainWindow::executeCommand);
    connect(button,
            &CommandButton::selectionRequested,
            this,
            &MainWindow::handleSelectionRequest);
    connect(button,
            &CommandButton::resizeStarted,
            this,
            &MainWindow::beginGroupResize);
    connect(button,
            &CommandButton::resizeDeltaChanged,
            this,
            &MainWindow::applyGroupResize);
    connect(button,
            &CommandButton::resizeFinished,
            this,
            &MainWindow::endGroupResize);
    connect(button,
            &CommandButton::geometryChanged,
            this,
            &MainWindow::updateCanvasExtent);

    buttons.append(button);
    updateCanvasExtent();
}

void MainWindow::editButton()
{
    CommandButton *button = qobject_cast<CommandButton *>(sender());
    if (!button) {
        return;
    }

    EditDialog dialog(button->getButtonLabel(), button->getCommandText(), this);
    const int result = dialog.exec();

    if (result == QDialog::Accepted) {
        button->setButtonLabel(dialog.getButtonLabel());
        button->setCommandText(dialog.getCommand());
    } else if (result == 2) {
        selectedButtons.removeOne(button);
        resizeStartingSizes.remove(button);
        buttons.removeOne(button);
        button->deleteLater();
        updateCanvasExtent();
    }
}

void MainWindow::organizeButtons()
{
    const int margin = 20;
    const int spacing = 10;
    int x = margin;
    int y = margin;
    int maximumHeightInRow = 0;
    const int canvasWidth = canvas->width();

    for (CommandButton *button : buttons) {
        if (x + button->width() > canvasWidth - margin && x > margin) {
            x = margin;
            y += maximumHeightInRow + spacing;
            maximumHeightInRow = 0;
        }

        button->move(x, y);
        x += button->width() + spacing;
        maximumHeightInRow = qMax(maximumHeightInRow, button->height());
    }

    updateCanvasExtent();
}

void MainWindow::makeAllButtonsSameSize()
{
    if (buttons.isEmpty()) {
        QMessageBox::information(this,
                                 "No Buttons",
                                 "There are no command buttons to resize.");
        return;
    }

    if (selectedButtons.isEmpty()) {
        QMessageBox::information(
            this,
            "Select a Reference Button",
            "Select the button whose size you want to copy, then click "
            "Make All Same Size.");
        return;
    }

    // selectedButtons is maintained in selection order, so the last item is
    // the most recently selected button. Its current size is the template.
    CommandButton *referenceButton = selectedButtons.constLast();
    const QSize referenceSize = referenceButton->size();

    for (CommandButton *button : buttons) {
        button->resize(referenceSize);
    }

    updateCanvasExtent();
}

void MainWindow::executeCommand(const QString &command)
{
    if (command.trimmed().isEmpty()) {
        QMessageBox::information(this,
                                 "No Command",
                                 "No command has been set for this button.");
        return;
    }

    QStringList arguments;
    arguments << "--"
              << "bash"
              << "-c"
              << command + "; echo 'Press Enter to close...'; read";

    QProcess::startDetached("gnome-terminal", arguments);
}

void MainWindow::handleSelectionRequest(CommandButton *button,
                                        bool toggleSelection,
                                        bool preserveGroup)
{
    if (!button) {
        return;
    }

    if (preserveGroup) {
        return;
    }

    if (toggleSelection) {
        setButtonSelected(button, !button->isSelected());
        return;
    }

    selectOnly(button);
}

void MainWindow::beginGroupResize(CommandButton *sourceButton)
{
    if (!sourceButton) {
        return;
    }

    if (!sourceButton->isSelected()) {
        selectOnly(sourceButton);
    }

    resizeStartingSizes.clear();
    for (CommandButton *button : selectedButtons) {
        resizeStartingSizes.insert(button, button->size());
    }
}

void MainWindow::applyGroupResize(CommandButton *sourceButton, const QSize &delta)
{
    if (!sourceButton || resizeStartingSizes.isEmpty()) {
        return;
    }

    for (auto it = resizeStartingSizes.constBegin();
         it != resizeStartingSizes.constEnd();
         ++it) {
        CommandButton *button = it.key();
        const QSize startingSize = it.value();

        const int newWidth = qMax(button->minimumWidth(),
                                  startingSize.width() + delta.width());
        const int newHeight = qMax(button->minimumHeight(),
                                   startingSize.height() + delta.height());

        button->resize(newWidth, newHeight);
    }
}

void MainWindow::endGroupResize(CommandButton *sourceButton)
{
    Q_UNUSED(sourceButton)
    resizeStartingSizes.clear();
    updateCanvasExtent();
}

void MainWindow::updateCanvasExtent()
{
    const int margin = 40;
    int requiredWidth = 800;
    int requiredHeight = 600;

    if (scrollArea && scrollArea->viewport()) {
        requiredWidth = qMax(requiredWidth, scrollArea->viewport()->width());
        requiredHeight = qMax(requiredHeight, scrollArea->viewport()->height());
    }

    for (CommandButton *button : buttons) {
        requiredWidth = qMax(requiredWidth, button->geometry().right() + margin);
        requiredHeight = qMax(requiredHeight, button->geometry().bottom() + margin);
    }

    canvas->resize(requiredWidth, requiredHeight);
}

void MainWindow::clearSelection()
{
    const QList<CommandButton *> previousSelection = selectedButtons;
    selectedButtons.clear();

    for (CommandButton *button : previousSelection) {
        button->setSelected(false);
    }
}

void MainWindow::selectOnly(CommandButton *button)
{
    if (selectedButtons.size() == 1 && selectedButtons.first() == button) {
        return;
    }

    clearSelection();
    setButtonSelected(button, true);
}

void MainWindow::setButtonSelected(CommandButton *button, bool selected)
{
    if (!button) {
        return;
    }

    button->setSelected(selected);

    if (selected) {
        if (!selectedButtons.contains(button)) {
            selectedButtons.append(button);
        }
    } else {
        selectedButtons.removeOne(button);
    }
}

QJsonObject MainWindow::buttonToJson(CommandButton *button) const
{
    QJsonObject object;
    object["label"] = button->getButtonLabel();
    object["command"] = button->getCommandText();
    object["x"] = button->x();
    object["y"] = button->y();
    object["width"] = button->width();
    object["height"] = button->height();
    return object;
}

void MainWindow::saveToJson(const QString &filename)
{
    QJsonArray array;
    for (CommandButton *button : buttons) {
        array.append(buttonToJson(button));
    }

    const QJsonDocument document(array);
    QFile file(filename);

    if (!file.open(QIODevice::WriteOnly)) {
        qWarning("Could not save buttons.json");
        return;
    }

    file.write(document.toJson(QJsonDocument::Indented));
}

void MainWindow::loadFromJson(const QString &filename)
{
    QFile file(filename);

    if (!file.exists()) {
        return;
    }

    if (!file.open(QIODevice::ReadOnly)) {
        qWarning("Could not open buttons.json");
        return;
    }

    const QByteArray data = file.readAll();
    const QJsonDocument document = QJsonDocument::fromJson(data);

    if (!document.isArray()) {
        qWarning("Invalid buttons.json format");
        return;
    }

    clearSelection();
    for (CommandButton *button : buttons) {
        button->deleteLater();
    }
    buttons.clear();

    const QJsonArray array = document.array();
    for (const QJsonValue &value : array) {
        const QJsonObject object = value.toObject();

        const QString label = object["label"].toString();
        const QString command = object["command"].toString();
        const int x = object["x"].toInt();
        const int y = object["y"].toInt();
        const int width = object["width"].toInt(120);
        const int height = object["height"].toInt(40);

        createButton(label, command, QPoint(x, y), QSize(width, height));
    }

    updateCanvasExtent();
}
